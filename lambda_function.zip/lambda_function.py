import boto3
import fitz  # PyMuPDF
import io

def lambda_handler(event, context):
    # Retrieve the event data
    source_bucket = event['Records'][0]['s3']['bucket']['name']
    source_key = event['Records'][0]['s3']['object']['key']
    
    # Initialize S3 clients
    s3 = boto3.client('s3')
    
    # Download the PDF file from the source bucket
    response = s3.get_object(Bucket=source_bucket, Key=source_key)
    pdf_content = response['Body'].read()
    
    # Extract text from the PDF using PyMuPDF (fitz)
    pdf_document = fitz.open(stream=io.BytesIO(pdf_content), filetype="pdf")
    text = ""
    
    for page_num in range(pdf_document.page_count):
        page = pdf_document.load_page(page_num)
        text += page.get_text()
    
    pdf_document.close()
    
    # Upload the text document to the destination bucket
    destination_bucket = 'destination-pdf-bucket'
    destination_key = f'{source_key.split(".")[0]}.txt'
    
    s3.put_object(Bucket=destination_bucket, Key=destination_key, Body=text, ContentType='text/plain')
    
    return {
        'statusCode': 200,
        'body': 'Text document created successfully.'
    }
